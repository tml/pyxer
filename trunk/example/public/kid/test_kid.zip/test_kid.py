class KidTemplateManager:

    def __init__(self):
        self.pool = []

    def load(self, path):
        print "Getting", path
        import kid
        source = open(path, "rb").read()
        template = kid.load_template(
            source,
            cache=False,
            ns=dict(load=self.load))
        self.pool.append(template)
        return template

template = KidTemplateManager().load("index.html")
print template.serialize()
